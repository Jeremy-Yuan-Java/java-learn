### 书籍

- **《Java8 In Action》**
- **《写给大忙人看的Java SE 8》**

上述书籍的PDF版本见 https://shimo.im/docs/CPB0PK05rP4CFmI2/ 中的 “Java 书籍推荐”。

### 开源文档

- **【译】Java 8 简明教程**：<https://github.com/wizardforcel/modern-java-zh>
- **30 seconds of java8:**  <https://github.com/biezhi/30-seconds-of-java8>

### 视频

- **尚硅谷 Java 8 新特性**

视频资源见： https://shimo.im/docs/CPB0PK05rP4CFmI2/ 。

